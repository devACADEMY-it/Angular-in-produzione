import {NgModule} from '@angular/core';
import {MoviesRoutingModule} from './movies-routing.module';
import {MoviesComponent} from './movies.component';
import {MovieDetailComponent} from './movie-detail.component';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  imports: [ SharedModule, MoviesRoutingModule ],
  declarations: [
    MoviesComponent,
    MovieDetailComponent,
  ]
})
export class MoviesModule {}
