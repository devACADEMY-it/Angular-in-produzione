import {inject, TestBed} from '@angular/core/testing';
import {DashboardComponent} from './dashboard.component';
import {Router} from '@angular/router';
import {MovieService} from '../model/movie.service';

let routerSpy;
let movieServiceSpy;
describe('Dashboard Component', () => {
  beforeEach(() => {
    routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    movieServiceSpy = jasmine.createSpyObj('MovieService', ['getMovies']);

    TestBed.configureTestingModule({
      declarations: [DashboardComponent],
      providers: [
        { provide: Router, useValue: routerSpy },
        { provide: MovieService, useValue: movieServiceSpy }
      ]
    });
  });

  it(`should navigate to '/movies/1`, () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const app = fixture.componentInstance;

    app.onSelect({ id: '1', title: 'Il padrino', director: 'Francis Ford Coppola', year: 1972, rating: 8 });
    expect(routerSpy.navigateByUrl).toHaveBeenCalledWith('/movies/1');
  });
});
