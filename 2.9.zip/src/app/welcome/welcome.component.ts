import {Component, OnInit} from '@angular/core';
import {UserService} from '../model/user.service';

@Component({
  selector: 'app-welcome',
  template: `<p class="content">{{welcome}}</p>`
})
export class WelcomeComponent implements OnInit {
  welcome: string;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.welcome = this.userService.isLoggedIn ? `Bentornato, ${this.userService.user.name}` : 'Log In';
  }
}
