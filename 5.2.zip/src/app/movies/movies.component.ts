import {Component, OnInit} from '@angular/core';
import {MovieService} from '../model/movie.service';
import {Movie} from '../model/movie';
import {Observable} from 'rxjs';
import {Router} from '@angular/router';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styles: [
    `
    article.message:hover {
      cursor: pointer;
    }
    `
  ]
})
export class MoviesComponent implements OnInit {
  title: string;
  movies: Observable<Movie[]>;

  constructor(
    private router: Router,
    private moviesService: MovieService
  ) {
    this.title = 'Tutti i miei film preferiti';
  }

  ngOnInit(): void {
    this.movies = this.moviesService.getMovies();
  }

  onSelect(movie: Movie) {
    this.router.navigate(['../movies', movie.id]);
  }

  getImageSrc(movie: Movie) {
    return `/assets/images/${movie.imageSrc}.jpg`;
  }

  onChangeTitle() {
    this.title = this.title + Math.random().toString(10).substring(2);
  }
}
