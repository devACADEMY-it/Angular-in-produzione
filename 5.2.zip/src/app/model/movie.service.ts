import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Movie} from './movie';
import {catchError, map} from 'rxjs/operators';

@Injectable()
export class MovieService {
  readonly ENDPOINT = 'api/movies';
  constructor(private http: HttpClient) {}

  // Ritorna la lista dei movie
  getMovies(): Observable<Movie[]> {
    return this.http.get<Movie[]>(this.ENDPOINT).pipe(
      catchError(this.handleError('getMovies'))
    ) as Observable<Movie[]>;
  }

  // Ritorna il dettaglio di un movie
  getMovie(id: number | string): Observable<Movie> {
    const url = `${this.ENDPOINT}/${id}`;
    return this.http.get<Movie>(url).pipe(
      catchError(this.handleError(`get movie by id ${id}`))
    ) as Observable<Movie>;
  }

  // Aggiorna un movie
  update(movie: Movie): Observable<Movie> {
    return this.http.put(this.ENDPOINT, movie, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }).pipe(
      catchError(this.handleError(`update movie with id ${movie.id}`))
    ) as Observable<Movie>;
  }

  private handleError<T>(operation = 'operation') {
    return (error: HttpErrorResponse): Observable<T> => {

      console.error(error); // log to console instead

      const message = (error.error instanceof ErrorEvent) ?
        error.error.message :
        `server returned code ${error.status} with body "${error.error}"`;

      throw new Error(`${operation} failed: ${message}`);
    };
  }
}
