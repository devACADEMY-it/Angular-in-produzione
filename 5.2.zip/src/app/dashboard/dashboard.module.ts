import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import {SharedModule} from '../shared/shared.module';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
];

@NgModule({
  imports: [SharedModule, RouterModule.forRoot(routes)],
  declarations: [DashboardComponent]
})
export class DashboardModule { }
