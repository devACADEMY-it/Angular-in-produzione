import {Component, OnInit} from '@angular/core';
import {MovieService} from '../model/movie.service';
import {Movie} from '../model/movie';
import {Router} from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: [
    `
    article.message:hover {
      cursor: pointer;
    }
    `
  ]
})
export class DashboardComponent implements OnInit {
  topMovies: Movie[];

  constructor(
    private router: Router,
    private movieService: MovieService
  ) {
    this.topMovies = [];
  }

  ngOnInit(): void {
    this.movieService.getMovies().subscribe(movies => {
      this.topMovies = movies.sort((a: Movie, b: Movie) =>
        a.rating < b.rating ? -1 : (a.rating > b.rating) ? 1 : 0
      ).slice(0, 3);
    });
  }

  onSelect(movie: Movie) {
    const url = `/movies/${movie.id}`;
    this.router.navigateByUrl(url);
  }
}
