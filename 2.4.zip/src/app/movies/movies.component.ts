import {Component} from '@angular/core';

@Component({
  selector: 'app-movies',
  template: `<h2 class="subtitle">Movies</h2>`
})
export class MoviesComponent {}
