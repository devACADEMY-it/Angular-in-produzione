import {Component} from '@angular/core';

@Component({
  selector: 'app-movie-detail',
  template: `<h2 class="subtitle">Detail</h2>`
})
export class MovieDetailComponent {}
