import {Component} from '@angular/core';

@Component({
  selector: 'app-dashboard',
  template: `<h2 class="subtitle">Dashboard</h2>`
})
export class DashboardComponent {}
