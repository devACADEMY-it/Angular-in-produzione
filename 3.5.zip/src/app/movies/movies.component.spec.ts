import {of} from 'rxjs';
import {TestBed} from '@angular/core/testing';
import {MoviesComponent} from './movies.component';
import {MovieService} from '../model/movie.service';

describe('Movies Component', () => {
  beforeEach(() => {
    const fakeData = [
      { id: '1', title: 'Il padrino', director: 'Francis Ford Coppola', year: 1972, rating: 8 },
      { id: '2', title: 'Il mago di Oz', director: 'Victor Fleming', year: 1939, rating: 5 },
      { id: '3', title: 'Citizen Kane', director: 'Orson Welles', year: 1941, rating: 8 }
    ];

    const movieServiceStub = jasmine.createSpyObj('MovieService', ['getMovies']);
    const getMoviesSpy = movieServiceStub.getMovies.and.returnValue(of(fakeData));

    TestBed.configureTestingModule({
      declarations: [MoviesComponent],
      providers: [{
        provide: MovieService,
        useValue: movieServiceStub
      }]
    });
  });
});
