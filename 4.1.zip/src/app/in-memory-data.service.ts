import { InMemoryDbService } from 'angular-in-memory-web-api';
import {Movie} from './model/movie';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const movies: Movie[] = [
      { id: '1', title: 'Il padrino', director: 'Francis Ford Coppola', year: 1972, rating: 8 },
      { id: '2', title: 'Il mago di Oz', director: 'Victor Fleming', year: 1939, rating: 5 },
      { id: '3', title: 'Citizen Kane', director: 'Orson Welles', year: 1941, rating: 8 },
      { id: '4', title: 'Le ali della libertà', director: 'Frank Darabont', year: 1994, rating: 7 },
      { id: '5', title: 'Pulp Fiction', director: 'Quentin Tarantino', year: 1994, rating: 9 },
      { id: '6', title: 'Casablanca', director: 'Michael Curtiz', year: 1942, rating: 2 },
      { id: '7', title: 'Il padrino: Parte 2', director: 'Francis Ford Coppola', year: 1974, rating: 7 },
      { id: '8', title: 'ET', director: 'Steven Spielberg', year: 1982, rating: 5 },
      { id: '9', title: '2001 - Odissea nello spazio', director: 'Stanley Kubrick', year: 1968, rating: 6 },
      { id: '10', title: 'Schindler\'s List', director: 'Steven Spielberg', year: 1993, rating: 9 }
    ];

    return { movies };
  }
}
