import {UserService} from '../model/user.service';
import {async, TestBed} from '@angular/core/testing';
import {WelcomeComponent} from './welcome.component';

let userServiceStub: Partial<UserService>;
describe('WelcomeComponent', () => {
  beforeEach(() => {
    userServiceStub = {
      isLoggedIn: true,
      user: { name: 'Adriano' }
    };

    TestBed.configureTestingModule({
      declarations: [WelcomeComponent],
      providers: [{
        provide: UserService,
        useValue: userServiceStub
      }]
    });
  });

  it('should welcome the user', () => {
    const fixture = TestBed.createComponent(WelcomeComponent);
    const app = fixture.componentInstance;
    const userService = TestBed.inject(UserService);

    fixture.detectChanges();
    const p = fixture.nativeElement.querySelector('p.content');
    const content = p.textContent;
    expect(content).toEqual('Bentornato, Adriano');
  });

  it('should request log in if not logged in', () => {
    const fixture = TestBed.createComponent(WelcomeComponent);
    const app = fixture.componentInstance;
    const userService = TestBed.inject(UserService);
    userService.isLoggedIn = false;
    fixture.detectChanges();
    const p = fixture.nativeElement.querySelector('p.content');
    const content = p.textContent;
    expect(content).toEqual('Log In');
  });
});

