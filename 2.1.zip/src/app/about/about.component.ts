import {Component} from '@angular/core';

@Component({
  template: `
    <h2 class="subtitle">About</h2>
  `
})
export class AboutComponent { }
