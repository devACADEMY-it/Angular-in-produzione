import {Component, OnInit} from '@angular/core';

@Component({
  template: `<p class="content">{{welcome}}</p>`
})
export class WelcomeComponent implements OnInit {
  welcome: string;

  constructor() {}

  ngOnInit(): void {
    this.welcome = 'Bentornato, camrhack';
  }
}
