import {MovieService} from './movie.service';
import {Movie} from './movie';
import {defer, of} from 'rxjs';

function asyncData<T>(data: T) {
  return defer(() => Promise.resolve(data));
}

let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy };
let movieService: MovieService;

describe('Movie Service', () => {
  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put']);
    movieService = new MovieService(httpClientSpy as any);
  });

  it('should return expected movies', () => {
    const expectedMovies: Movie[] = [
      { id: '1', title: 'Il padrino', director: 'Francis Ford Coppola', year: 1972, rating: 8 },
      { id: '2', title: 'Il mago di Oz', director: 'Victor Fleming', year: 1939, rating: 5 },
      { id: '3', title: 'Citizen Kane', director: 'Orson Welles', year: 1941, rating: 8 }
    ];

    httpClientSpy.get.and.returnValue(asyncData(expectedMovies));

    movieService.getMovies().subscribe(movies => expect(movies).toEqual(expectedMovies));
    expect(httpClientSpy.get.calls.count()).toBe(1);
  });
});
