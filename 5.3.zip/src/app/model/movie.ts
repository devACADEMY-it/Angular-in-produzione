export interface Movie {
  id: string;
  title: string;
  director: string;
  year: number;
  imageSrc?: string;
  rating: number;
}
