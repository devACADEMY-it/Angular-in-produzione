import {Component, OnInit} from '@angular/core';
import {MovieService} from '../model/movie.service';
import {ActivatedRoute, Router} from '@angular/router';
import {Movie} from '../model/movie';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html'
})
export class MovieDetailComponent implements OnInit {
  movie: Movie;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private movieService: MovieService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(pmap => this.getMovie(pmap.get('id')));
  }

  getMovie(id: string) {
    this.movieService.getMovie(id).subscribe(movie => {
      if (movie) {
        this.movie = movie;
      } else {
        this.gotoList();
      }
    });
  }

  saveMovie() {}

  cancel() {
    this.gotoList();
  }

  gotoList() {
    this.router.navigate(['../'], {relativeTo: this.route});
  }
}
