import {UserService} from '../model/user.service';
import {async, TestBed} from '@angular/core/testing';
import {WelcomeComponent} from './welcome.component';

let userServiceStub: Partial<UserService>;
describe('WelcomeComponent', () => {
  beforeEach(() => {
    userServiceStub = {
      isLoggedIn: true,
      user: { name: 'Adriano' }
    };

    TestBed.configureTestingModule({
      declarations: [WelcomeComponent],
      providers: [{
        provide: UserService,
        useValue: userServiceStub
      }]
    });
  });
});

