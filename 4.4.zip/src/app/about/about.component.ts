import {Component} from '@angular/core';

@Component({
  selector: 'app-about',
  template: `<h2 class="subtitle">About</h2>`
})
export class AboutComponent { }
