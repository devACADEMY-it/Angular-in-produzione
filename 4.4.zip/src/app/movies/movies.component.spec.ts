import {of} from 'rxjs';
import {TestBed} from '@angular/core/testing';
import {MoviesComponent} from './movies.component';
import {MovieService} from '../model/movie.service';
import {RouterTestingModule} from '@angular/router/testing';
import {By} from '@angular/platform-browser';

const fakeData = [
  { id: '1', title: 'Il padrino', director: 'Francis Ford Coppola', year: 1972, rating: 8 },
  { id: '2', title: 'Il mago di Oz', director: 'Victor Fleming', year: 1939, rating: 5 },
  { id: '3', title: 'Citizen Kane', director: 'Orson Welles', year: 1941, rating: 8 }
];
let movieServiceStub;

describe('Movies Component', () => {
  beforeEach(() => {
    movieServiceStub  = jasmine.createSpyObj('MovieService', ['getMovies']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [MoviesComponent],
      providers: [{
        provide: MovieService,
        useValue: movieServiceStub
      }]
    });
  });

  it('should call getMovies on ngOnInit', () => {
    const fixture = TestBed.createComponent(MoviesComponent);
    const app = fixture.componentInstance;
    const getMoviesSpy = movieServiceStub.getMovies.and.returnValue(of(fakeData));

    fixture.detectChanges(); // ngOnInit
    expect(getMoviesSpy).toHaveBeenCalled();
  });

  it('should render a list of movies', () => {
    const fixture = TestBed.createComponent(MoviesComponent);
    const app = fixture.componentInstance;
    const getMoviesSpy = movieServiceStub.getMovies.and.returnValue(of(fakeData));

    fixture.detectChanges(); // ngOnInit
    const totalColumn = fixture.debugElement.queryAll(By.css('div.column.is-4')).length;
    expect(totalColumn).toBe(3);
  });
});
